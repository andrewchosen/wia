$(document).ready(function(){
	$(".map-image").attr("src", "images/map.png");
	console.log($(".map-image").attr("src"));
});